﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public Text healthTextBox;
    PlayerHealth playerHealth;

    void Awake()
    {
        //do not remove
        DontDestroyOnLoad(this);
        healthTextBox = GameObject.FindGameObjectWithTag("HealthText").GetComponent<Text>();
        playerHealth = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerHealth>();
    }

    private void Update()
    {
        healthTextBox.text = "Health: " + playerHealth.Health;
    }

}
